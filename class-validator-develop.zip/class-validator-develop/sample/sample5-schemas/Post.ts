export class Post {
  title: string;
  text: string;
  rating: number;
  email: string;
  site: string;
  createDate: Date;
  tags: string[];
}
