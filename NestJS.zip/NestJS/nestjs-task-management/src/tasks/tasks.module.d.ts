export declare class TasksModule {
}
