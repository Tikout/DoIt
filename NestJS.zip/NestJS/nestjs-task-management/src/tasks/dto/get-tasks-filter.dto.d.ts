import { TaskStatus } from '../task-status.enum';
export declare class GetTasksFilterDto {
    status?: TaskStatus;
    search?: string;
}
