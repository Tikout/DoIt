import { TaskStatus } from '../task-status.enum';
export declare class UpdateTaskStatusDto {
    status: TaskStatus;
}
