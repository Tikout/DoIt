import { Module } from '@nestjs/common';
import { TasksModule } from './tasks/tasks.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
// import { configValidationSchema } from './config.schema';

@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: [`.env.stage.${process.env.STAGE}`],
      // validationSchema: configValidationSchema,
    }),
    TasksModule,
    TypeOrmModule.forRoot({
        type: 'postgres',
        autoLoadEntities: true,
        synchronize: true,
        host: 'localhost',
        port: 5432,
        username: 'postgres',
        password: 'postgres',
        database: 'task-management',
      }),
      //TypeOrmModule.forRootAsync({ CONFIGURATION ERROR
      //  imports: [ConfigModule], CONFIGURATION ERROR
      //  inject: [ConfigService], CONFIGURATION ERROR
      //  useFactory: async (configService: ConfigService) => ({ CONFIGURATION ERROR
      //    type: 'postgres', CONFIGURATION ERROR
      //    autoLoadEntities: true, CONFIGURATION ERROR
      //    synchronize: true, CONFIGURATION ERROR
      //    host: configService.get('DB_HOST'), CONFIGURATION ERROR
      //    port: configService.get('DB_PORT'), CONFIGURATION ERROR
      //    username: configService.get('DB_USERNAME'), CONFIGURATION ERROR
      //    password: configService.get('DB_PASSWORD'), CONFIGURATION ERROR
      //    database: configService.get('DB_DATABASE'), CONFIGURATION ERROR
      //  }), CONFIGURATION ERROR
      //}), CONFIGURATION ERROR
    AuthModule,
  ],
})
export class AppModule {}