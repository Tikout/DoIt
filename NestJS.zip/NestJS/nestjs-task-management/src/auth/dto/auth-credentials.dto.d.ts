export declare class AuthCredentialsDto {
    username: string;
    password: string;
}
