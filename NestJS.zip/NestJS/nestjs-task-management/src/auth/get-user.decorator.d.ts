export declare const GetUser: (...dataOrPipes: any[]) => ParameterDecorator;
