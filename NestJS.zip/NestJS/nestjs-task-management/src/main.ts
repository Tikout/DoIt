import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { TransformInterceptor } from './transform.interceptor';
import { Logger } from '@nestjs/common';
import * as dotenv from 'dotenv';

// console.log(process.env); Pokazuje nam rożne zmienne i ich wartości, możemy się dostać do jakiejś konkretnej dodając . i wpisując co trzeba
// Aby dodać swoją zmienną musimy przed start:dev napisać np MOJE_TAK=jakaś wartość

async function bootstrap() {
  dotenv.config();
  const logger = new Logger();
  const app = await NestFactory.create(AppModule);
  app.useGlobalPipes(new ValidationPipe());
  app.useGlobalInterceptors(new TransformInterceptor())
  const port = 3030;
  await app.listen(port);
  logger.log(`Application listening on port: ${port}`)
}
bootstrap();
